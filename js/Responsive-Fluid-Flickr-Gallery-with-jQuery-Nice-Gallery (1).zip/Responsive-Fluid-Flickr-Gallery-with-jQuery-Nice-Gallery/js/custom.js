/*
	Programmer: Lukasz Czerwinski
	CodeCanyon: http://codecanyon.net/user/Lukasz_Czerwinski
	 
	If this script you like, please put a comment on codecanyon.
	
*/

$(document).ready(function (){ 
  //Usage 
  $("#gallery").flickrGallery({
            //FLICKR API KEY
//            Key: 'YOUR API KEY',
//            //Secret
//            Secret: 'YOUR SECRET',
//            //FLICKR user ID
//            User: 'YOUR ID',
//            //Flickr PhotoSet ID
//            PhotoSet: 'YOUR ALBUM ID'
  });
}); 
